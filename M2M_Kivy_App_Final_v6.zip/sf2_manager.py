"""
SF2 Manager - 사운드폰트 다운로드 및 관리
Dropbox 링크를 통한 초기 자산 확보
"""

import os
import requests
import zipfile
from kivy.clock import Clock
from threading import Thread

class SF2Manager:
    # 사용자가 제공한 Dropbox 직통 링크 (dl=1로 변경하여 직접 다운로드)
    SF2_URL = "https://www.dropbox.com/scl/fi/7njmbb2uv2ok164u1k3jh/shared_folder.zip?rlkey=ctvpt5ll7r7gcw595clhhskj9&st=amd1zj01&dl=1"
    
    def __init__(self, app_data_dir):
        self.app_data_dir = app_data_dir
        self.sf2_dir = os.path.join(self.app_data_dir, "sf2_library")
        os.makedirs(self.sf2_dir, exist_ok=True)
        
    def is_sf2_ready(self):
        """SF2 파일이 이미 존재하는지 확인"""
        if not os.path.exists(self.sf2_dir):
            return False
        # 디렉토리에 .sf2 파일이 하나라도 있으면 준비된 것으로 간주
        files = os.listdir(self.sf2_dir)
        return any(f.lower().endswith('.sf2') for f in files)

    def download_default_sf2(self, on_progress=None, on_complete=None, on_error=None):
        """백그라운드에서 SF2 다운로드 시작"""
        thread = Thread(target=self._download_task, args=(on_progress, on_complete, on_error))
        thread.daemon = True
        thread.start()

    def _download_task(self, on_progress, on_complete, on_error):
        try:
            zip_path = os.path.join(self.app_data_dir, "default_sf2.zip")
            
            # 1. 다운로드
            response = requests.get(self.SF2_URL, stream=True, timeout=30)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if on_progress and total_size > 0:
                            progress = (downloaded / total_size) * 100
                            Clock.schedule_once(lambda dt, p=progress: on_progress(p, "다운로드 중..."))

            # 2. 압축 해제
            if on_progress:
                Clock.schedule_once(lambda dt: on_progress(95, "압축 해제 중..."))
            
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.sf2_dir)
            
            # 임시 zip 파일 삭제
            os.remove(zip_path)
            
            if on_complete:
                Clock.schedule_once(lambda dt: on_complete())
                
        except Exception as e:
            print(f"SF2 Download Error: {e}")
            if on_error:
                Clock.schedule_once(lambda dt: on_error(str(e)))

    def get_sf2_list(self):
        """사용 가능한 SF2 파일 목록 반환"""
        if not os.path.exists(self.sf2_dir):
            return []
        return [f for f in os.listdir(self.sf2_dir) if f.lower().endswith('.sf2')]
