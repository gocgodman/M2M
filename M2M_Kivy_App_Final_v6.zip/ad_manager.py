"""
Ad Manager - AdMob 광고 연동 관리
Android/iOS 환경에서 광고 표시 지원
"""

from kivy.utils import platform

class AdManager:
    def __init__(self, app_id="ca-app-pub-3940256099942544~3347511713"): # 테스트용 App ID
        self.app_id = app_id
        self.banner_id = "ca-app-pub-3940256099942544/6300978111" # 테스트용 배너 ID
        self.ads = None
        
        if platform == 'android':
            try:
                # KivMob 또는 jnius를 통한 AdMob 연동 로직
                # 실제 빌드 시 kivmob 라이브러리 필요
                # from kivmob import KivMob
                # self.ads = KivMob(self.app_id)
                # self.ads.new_banner(self.banner_id, top_pos=False)
                pass
            except Exception as e:
                print(f"AdMob initialization failed: {e}")

    def show_banner(self):
        if self.ads:
            self.ads.show_banner()
        else:
            print("Banner Ad: [Showing Placeholder]")

    def hide_banner(self):
        if self.ads:
            self.ads.hide_banner()

    def request_interstitial(self, ad_id="ca-app-pub-3940256099942544/1033173712"):
        if self.ads:
            self.ads.new_interstitial(ad_id)
            self.ads.request_interstitial()

    def show_interstitial(self):
        if self.ads:
            self.ads.show_interstitial()
