#!/bin/bash
# Scipy 빌드 오류 해결을 위한 NDK r21e 자동 설치 및 설정 스크립트 (v6)

NDK_VERSION="r21e"
# 현재 사용자의 홈 디렉토리를 절대 경로로 가져옵니다.
USER_HOME=$(eval echo ~$USER)
NDK_DIR="$USER_HOME/.buildozer/android/platform/android-ndk-$NDK_VERSION"

echo "Checking for Legacy NDK (r21e) for Scipy build..."

if [ ! -d "$NDK_DIR" ]; then
    echo "Legacy NDK not found. Downloading NDK $NDK_VERSION..."
    mkdir -p "$USER_HOME/.buildozer/android/platform"
    cd "$USER_HOME/.buildozer/android/platform"
    wget -q https://dl.google.com/android/repository/android-ndk-$NDK_VERSION-linux-x86_64.zip
    unzip -q android-ndk-$NDK_VERSION-linux-x86_64.zip
    rm android-ndk-$NDK_VERSION-linux-x86_64.zip
    echo "Legacy NDK installed at $NDK_DIR"
else
    echo "Legacy NDK already exists."
fi

# 환경 변수 설정 및 빌드 명령어 안내
export LEGACY_NDK=$NDK_DIR
echo "--------------------------------------------------"
echo "LEGACY_NDK is set to: $LEGACY_NDK"
echo "--------------------------------------------------"
echo "빌드를 시작하려면 아래 명령어를 복사해서 실행하세요:"
echo ""
echo "export LEGACY_NDK=$NDK_DIR && buildozer -v android debug"
echo "--------------------------------------------------"
