"""
GPU 최적화 설정
모바일 및 데스크톱 환경에서 GPU 가속 활성화
"""

import os
import sys
import torch


class GPUConfig:
    """GPU 설정 및 최적화"""
    
    @staticmethod
    def setup_gpu():
        """GPU 환경 설정"""
        config = {
            'device': 'cpu',
            'device_name': 'CPU',
            'cuda_available': False,
            'mps_available': False,
            'gpu_memory': 0,
            'optimizations': []
        }
        
        # CUDA (NVIDIA GPU)
        if torch.cuda.is_available():
            config['device'] = 'cuda'
            config['device_name'] = torch.cuda.get_device_name(0)
            config['cuda_available'] = True
            config['gpu_memory'] = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            
            # CUDA 최적화
            torch.backends.cudnn.enabled = True
            torch.backends.cudnn.benchmark = True
            config['optimizations'].append('cuDNN enabled')
            config['optimizations'].append('cuDNN benchmark mode')
            
            # 메모리 최적화
            torch.cuda.empty_cache()
            config['optimizations'].append('CUDA cache cleared')
            
        # MPS (Apple Silicon)
        elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            config['device'] = 'mps'
            config['device_name'] = 'Apple Silicon GPU'
            config['mps_available'] = True
            config['optimizations'].append('MPS backend enabled')
            
        # CPU 폴백
        else:
            config['device'] = 'cpu'
            config['device_name'] = 'CPU (No GPU)'
            
            # CPU 최적화
            if hasattr(torch, 'set_num_threads'):
                num_threads = os.cpu_count() or 4
                torch.set_num_threads(num_threads)
                config['optimizations'].append(f'CPU threads: {num_threads}')
        
        return config
    
    @staticmethod
    def optimize_for_mobile():
        """모바일 환경 최적화"""
        optimizations = []
        
        # 메모리 효율성 우선
        if torch.cuda.is_available():
            # 작은 배치 사이즈 사용
            torch.backends.cudnn.benchmark = False  # 모바일에서는 비활성화
            optimizations.append('Mobile: cuDNN benchmark disabled')
            
            # 메모리 단편화 방지
            os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:128'
            optimizations.append('Mobile: CUDA memory fragmentation reduced')
        
        # 저전력 모드
        if hasattr(torch, 'set_float32_matmul_precision'):
            torch.set_float32_matmul_precision('medium')
            optimizations.append('Mobile: Float32 precision reduced')
        
        return optimizations
    
    @staticmethod
    def get_optimal_batch_size(device):
        """디바이스에 맞는 최적 배치 사이즈 반환"""
        if device == 'cuda':
            # GPU 메모리에 따라 조정
            gpu_memory = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            if gpu_memory > 8:
                return 16
            elif gpu_memory > 4:
                return 8
            else:
                return 4
        elif device == 'mps':
            return 8
        else:
            return 2
    
    @staticmethod
    def enable_mixed_precision():
        """혼합 정밀도 학습/추론 활성화 (GPU 성능 향상)"""
        if torch.cuda.is_available():
            # CUDA AMP (Automatic Mixed Precision)
            return True
        return False
    
    @staticmethod
    def print_config(config):
        """설정 정보 출력"""
        print("=" * 50)
        print("GPU Configuration")
        print("=" * 50)
        print(f"Device: {config['device']}")
        print(f"Device Name: {config['device_name']}")
        print(f"CUDA Available: {config['cuda_available']}")
        print(f"MPS Available: {config['mps_available']}")
        if config['gpu_memory'] > 0:
            print(f"GPU Memory: {config['gpu_memory']:.2f} GB")
        print(f"\nOptimizations Applied:")
        for opt in config['optimizations']:
            print(f"  - {opt}")
        print("=" * 50)


# Android 특화 설정
def setup_android_gpu():
    """Android GPU 설정"""
    # Vulkan 백엔드 활성화 (Android GPU)
    os.environ['KIVY_GL_BACKEND'] = 'sdl2'
    
    # PyTorch Mobile 최적화
    if hasattr(torch, 'backends') and hasattr(torch.backends, 'vulkan'):
        if torch.backends.vulkan.is_available():
            print("✓ Vulkan backend available for Android GPU")
            return 'vulkan'
    
    # OpenGL ES 폴백
    print("✓ Using OpenGL ES for Android")
    return 'gles'


# iOS 특화 설정
def setup_ios_gpu():
    """iOS GPU 설정 (Metal)"""
    os.environ['KIVY_GL_BACKEND'] = 'sdl2'
    
    # Metal 백엔드
    if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        print("✓ Metal Performance Shaders (MPS) available")
        return 'mps'
    
    return 'metal'


# 플랫폼 감지 및 자동 설정
def auto_setup():
    """플랫폼 자동 감지 및 GPU 설정"""
    config = GPUConfig.setup_gpu()
    
    # Android
    try:
        import android
        backend = setup_android_gpu()
        config['platform'] = 'android'
        config['backend'] = backend
        config['optimizations'].extend(GPUConfig.optimize_for_mobile())
    except ImportError:
        pass
    
    # iOS
    if sys.platform == 'darwin' and 'arm' in os.uname().machine.lower():
        backend = setup_ios_gpu()
        config['platform'] = 'ios'
        config['backend'] = backend
        config['optimizations'].extend(GPUConfig.optimize_for_mobile())
    
    GPUConfig.print_config(config)
    return config


if __name__ == '__main__':
    # 테스트
    config = auto_setup()
