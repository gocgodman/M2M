"""
M2M (MP3 to MIDI) Kivy Mobile App
GPU 가속을 활용한 모바일 앱
"""

import os
import sys
from pathlib import Path

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.progressbar import ProgressBar
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.clock import Clock
from kivy.properties import StringProperty, BooleanProperty
from kivy.core.window import Window

# 모바일 권한 처리
try:
    from android.permissions import request_permissions, Permission
    request_permissions([
        Permission.READ_EXTERNAL_STORAGE,
        Permission.WRITE_EXTERNAL_STORAGE,
        Permission.INTERNET
    ])
    ANDROID = True
except ImportError:
    ANDROID = False

# 백엔드 모듈 import
from transcription_engine import TranscriptionEngine
from sf2_manager import SF2Manager
from ad_manager import AdManager


class MainScreen(BoxLayout):
    """메인 화면 레이아웃"""
    
    status_text = StringProperty("준비됨")
    is_processing = BooleanProperty(False)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = 10
        self.spacing = 10
        
        # 경로 설정
        self.app_data_dir = App.get_running_app().user_data_dir
        
        # 매니저 초기화
        self.engine = TranscriptionEngine()
        self.sf2_manager = SF2Manager(self.app_data_dir)
        self.ad_manager = AdManager()
        
        # UI 구성
        self.build_ui()
        
        # 광고 표시
        self.ad_manager.show_banner()
        
        # 초기 SF2 체크
        Clock.schedule_once(self.check_initial_assets, 1)
        
    def check_initial_assets(self, dt):
        """초기 자산(SF2) 확인 및 다운로드 안내"""
        if not self.sf2_manager.is_sf2_ready():
            self.show_download_dialog()

    def show_download_dialog(self):
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text="기본 사운드폰트(SF2)가 없습니다.\n다운로드하시겠습니까? (약 100MB+)"))
        
        btn_layout = BoxLayout(size_hint_y=None, height='50dp', spacing=10)
        
        def start_dl(instance):
            self.popup.dismiss()
            self.status_text = "기본 자산 다운로드 중..."
            self.status_label.text = self.status_text
            self.sf2_manager.download_default_sf2(
                on_progress=self.update_dl_progress,
                on_complete=self.on_dl_complete,
                on_error=self.on_dl_error
            )

        download_btn = Button(text="다운로드", on_press=start_dl)
        close_btn = Button(text="나중에", on_press=lambda x: self.popup.dismiss())
        
        btn_layout.add_widget(download_btn)
        btn_layout.add_widget(close_btn)
        content.add_widget(btn_layout)
        
        self.popup = Popup(title="초기 설정", content=content, size_hint=(0.8, 0.4))
        self.popup.open()

    def update_dl_progress(self, progress, message):
        self.progress_bar.value = progress
        self.add_log(message)

    def on_dl_complete(self):
        self.status_text = "준비됨"
        self.status_label.text = self.status_text
        self.progress_bar.value = 100
        self.add_log("✓ 기본 사운드폰트 다운로드 및 설치 완료")
        self.show_success("기본 사운드폰트가 설치되었습니다.")

    def on_dl_error(self, error_msg):
        self.status_text = "다운로드 실패"
        self.status_label.text = self.status_text
        self.add_log(f"✗ 다운로드 오류: {error_msg}")
        self.show_error(f"다운로드 중 오류가 발생했습니다:\n{error_msg}")

    def build_ui(self):
        """UI 요소 구성"""
        
        # 타이틀
        title = Label(
            text='M2M - MP3 to MIDI',
            size_hint=(1, 0.1),
            font_size='24sp',
            bold=True
        )
        self.add_widget(title)
        
        # 상태 표시
        self.status_label = Label(
            text=self.status_text,
            size_hint=(1, 0.1),
            font_size='16sp'
        )
        self.add_widget(self.status_label)
        
        # 진행률 바
        self.progress_bar = ProgressBar(
            max=100,
            value=0,
            size_hint=(1, 0.05)
        )
        self.add_widget(self.progress_bar)
        
        # 버튼 컨테이너
        button_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, 0.15),
            spacing=10
        )
        
        # 파일 선택 버튼
        self.select_btn = Button(
            text='MP3 파일 선택',
            on_press=self.select_file
        )
        button_layout.add_widget(self.select_btn)
        
        # 변환 시작 버튼
        self.convert_btn = Button(
            text='MIDI 변환',
            on_press=self.start_conversion,
            disabled=True
        )
        button_layout.add_widget(self.convert_btn)
        
        self.add_widget(button_layout)
        
        # 로그 영역
        log_label = Label(
            text='로그:',
            size_hint=(1, 0.05),
            font_size='14sp'
        )
        self.add_widget(log_label)
        
        scroll = ScrollView(size_hint=(1, 0.55))
        self.log_text = Label(
            text='',
            size_hint_y=None,
            font_size='12sp',
            halign='left',
            valign='top'
        )
        self.log_text.bind(texture_size=self.log_text.setter('size'))
        scroll.add_widget(self.log_text)
        self.add_widget(scroll)

        # 광고 배너 영역 추가
        self.ad_banner = Label(
            text='[ 광고 배너 영역 ]\n(AdMob 연동 가능)',
            size_hint=(1, 0.1),
            color=(0.5, 0.5, 0.5, 1),
            canvas_before=[
                {'type': 'Color', 'rgba': (0.9, 0.9, 0.9, 1)},
                {'type': 'Rectangle', 'pos': 'self.pos', 'size': 'self.size'}
            ]
        )
        # 실제 AdMob 연동 시 아래 위젯을 광고 위젯으로 교체
        self.add_widget(self.ad_banner)
        
        # 선택된 파일 경로
        self.selected_file = None
        
    def select_file(self, instance):
        """파일 선택 다이얼로그"""
        content = BoxLayout(orientation='vertical')
        
        # 파일 선택기
        if ANDROID:
            # Android 저장소 경로
            filechooser = FileChooserListView(
                path='/storage/emulated/0/',
                filters=['*.mp3', '*.wav', '*.m4a']
            )
        else:
            # 데스크톱 경로
            filechooser = FileChooserListView(
                path=str(Path.home()),
                filters=['*.mp3', '*.wav', '*.m4a']
            )
        
        content.add_widget(filechooser)
        
        # 버튼 레이아웃
        btn_layout = BoxLayout(size_hint=(1, 0.1), spacing=10)
        
        def on_select(instance):
            if filechooser.selection:
                self.selected_file = filechooser.selection[0]
                self.status_text = f"선택됨: {os.path.basename(self.selected_file)}"
                self.status_label.text = self.status_text
                self.convert_btn.disabled = False
                self.add_log(f"파일 선택: {self.selected_file}")
            popup.dismiss()
        
        select_btn = Button(text='선택', on_press=on_select)
        cancel_btn = Button(text='취소', on_press=lambda x: popup.dismiss())
        
        btn_layout.add_widget(select_btn)
        btn_layout.add_widget(cancel_btn)
        content.add_widget(btn_layout)
        
        popup = Popup(
            title='MP3 파일 선택',
            content=content,
            size_hint=(0.9, 0.9)
        )
        popup.open()
    
    def start_conversion(self, instance):
        """변환 시작"""
        if not self.selected_file:
            self.show_error("파일이 선택되지 않았습니다.")
            return
        
        self.is_processing = True
        self.convert_btn.disabled = True
        self.select_btn.disabled = True
        self.status_text = "변환 중..."
        self.status_label.text = self.status_text
        self.progress_bar.value = 0
        
        self.add_log("변환 시작...")
        
        # 백그라운드에서 변환 실행
        Clock.schedule_once(lambda dt: self.run_conversion(), 0.1)
    
    def run_conversion(self):
        """실제 변환 실행"""
        try:
            # 출력 파일 경로 설정
            output_dir = os.path.dirname(self.selected_file)
            if ANDROID:
                # Android에서는 앱 전용 디렉토리 사용
                output_dir = App.get_running_app().user_data_dir
            
            base_name = os.path.splitext(os.path.basename(self.selected_file))[0]
            output_file = os.path.join(output_dir, f"{base_name}_converted.mid")
            
            self.add_log(f"입력: {self.selected_file}")
            self.add_log(f"출력: {output_file}")
            
            # 진행률 콜백
            def progress_callback(progress, message):
                self.progress_bar.value = progress
                self.add_log(message)
            
            # 변환 실행
            success = self.engine.transcribe(
                self.selected_file,
                output_file,
                progress_callback=progress_callback
            )
            
            if success:
                self.status_text = "변환 완료!"
                self.add_log(f"✓ 변환 완료: {output_file}")
                self.show_success(f"MIDI 파일이 저장되었습니다:\n{output_file}")
            else:
                self.status_text = "변환 실패"
                self.add_log("✗ 변환 실패")
                self.show_error("변환에 실패했습니다.")
                
        except Exception as e:
            self.status_text = "오류 발생"
            self.add_log(f"✗ 오류: {str(e)}")
            self.show_error(f"오류가 발생했습니다:\n{str(e)}")
        
        finally:
            self.is_processing = False
            self.convert_btn.disabled = False
            self.select_btn.disabled = False
            self.status_label.text = self.status_text
    
    def add_log(self, message):
        """로그 추가"""
        current = self.log_text.text
        self.log_text.text = f"{current}\n{message}" if current else message
    
    def show_error(self, message):
        """에러 팝업"""
        popup = Popup(
            title='오류',
            content=Label(text=message),
            size_hint=(0.8, 0.3)
        )
        popup.open()
    
    def show_success(self, message):
        """성공 팝업"""
        popup = Popup(
            title='완료',
            content=Label(text=message),
            size_hint=(0.8, 0.3)
        )
        popup.open()


class M2MApp(App):
    """메인 앱 클래스"""
    
    def build(self):
        Window.clearcolor = (0.95, 0.95, 0.95, 1)
        return MainScreen()


if __name__ == '__main__':
    M2MApp().run()
