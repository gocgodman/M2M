# M2M (MP3 to MIDI) Kivy 모바일 앱

Jupyter 노트북의 MP3 to MIDI 변환 코드를 Kivy 프레임워크를 사용하여 GPU 가속을 지원하는 모바일 애플리케이션으로 재구성한 프로젝트입니다.

## 주요 기능

- **MP3 to MIDI 변환**: `transkun` v2 모델을 사용하여 오디오 파일을 MIDI로 변환합니다.
- **GPU 가속**: NVIDIA GPU(CUDA), Apple Silicon(MPS) 및 Android(Vulkan/OpenGL ES) 환경에서 PyTorch를 통해 GPU 가속을 지원하여 빠른 처리 속도를 제공합니다.
- **모바일 최적화**: Kivy를 사용하여 Android 및 iOS에서 실행 가능한 크로스플랫폼 앱으로 개발되었습니다.
- **간편한 UI**: 사용자가 쉽게 MP3 파일을 선택하고 변환을 시작할 수 있는 직관적인 인터페이스를 제공합니다.
- **실시간 로그**: 변환 과정의 모든 단계를 로그로 확인할 수 있습니다.

## 프로젝트 구조

```
/M2M_Kivy_App
├── main.py                 # Kivy 앱 메인 로직 및 UI
├── transcription_engine.py # MP3 to MIDI 변환 엔진 (GPU 가속)
├── gpu_config.py           # GPU 자동 감지 및 최적화 설정
├── requirements.txt        # Python 의존성 목록
├── buildozer.spec          # Android 빌드 설정 파일
├── build.sh                # 자동 빌드 스크립트
└── README.md               # 프로젝트 설명서
```

## 시스템 요구사항

- **데스크톱 (테스트용)**:
  - Python 3.8 이상
  - PyTorch, Kivy 및 기타 `requirements.txt`에 명시된 라이브러리
  - (선택) NVIDIA GPU 및 CUDA Toolkit

- **모바일 (빌드용)**:
  - Linux (Ubuntu 권장) 환경
  - Buildozer 및 해당 의존성 (Java, Android SDK/NDK)

## 설치 및 실행 (데스크톱 테스트)

1.  **저장소 복제**

    ```bash
    git clone <repository_url>
    cd M2M_Kivy_App
    ```

2.  **가상 환경 생성 및 활성화**

    ```bash
    python3 -m venv venv
    source venv/bin/activate
    ```

3.  **의존성 설치**

    ```bash
    pip install -r requirements.txt
    ```
    *참고: PyTorch는 시스템 환경(CPU/GPU)에 맞게 별도로 설치해야 할 수 있습니다. [공식 PyTorch 웹사이트](https://pytorch.org/get-started/locally/)를 참조하세요.*

4.  **애플리케이션 실행**

    ```bash
    python main.py
    ```

## Android 앱 빌드 방법

`build.sh` 스크립트는 Buildozer를 사용하여 Android APK를 빌드하는 과정을 자동화합니다.

1.  **빌드 스크립트 실행 권한 부여**

    ```bash
    chmod +x build.sh
    ```

2.  **빌드 스크립트 실행**

    ```bash
    ./build.sh
    ```

    이 스크립트는 다음 작업을 수행합니다:
    - Buildozer 설치
    - `buildozer.spec` 파일을 사용하여 Android 디버그 APK 빌드

3.  **결과 확인**

    빌드가 성공적으로 완료되면 `bin/` 디렉터리에 `m2m-1.0.0-arm64-v8a-debug.apk`와 같은 APK 파일이 생성됩니다. 이 파일을 Android 기기에 설치하여 테스트할 수 있습니다.

## GPU 가속 정보

- `gpu_config.py`가 앱 시작 시 자동으로 최적의 가속 환경을 감지하고 설정합니다.
- **NVIDIA GPU**: CUDA가 감지되면 `torch.backends.cudnn`을 활성화하여 성능을 극대화합니다.
- **Apple Silicon**: MPS(Metal Performance Shaders) 백엔드를 사용하여 Apple M-시리즈 칩에서 GPU 가속을 지원합니다.
- **Android**: PyTorch Mobile이 지원하는 Vulkan 또는 OpenGL ES 백엔드를 사용하도록 시도합니다. (빌드 레시피에 따라 성능이 달라질 수 있습니다.)
- **CPU Fallback**: 사용 가능한 GPU가 없으면 최적화된 CPU 스레드를 사용하여 처리합니다.
