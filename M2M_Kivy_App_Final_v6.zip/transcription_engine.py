"""
Transcription Engine - MP3 to MIDI 변환 엔진
사용자 제공 transcribe_file 함수 통합 버전
"""

import os
import sys
import torch
import subprocess
from pathlib import Path

# GPU 설정
from gpu_config import GPUConfig, auto_setup

class TranscriptionEngine:
    """MP3 to MIDI 변환 엔진 (Subprocess 기반 정밀 전사)"""
    
    def __init__(self):
        """초기화 및 GPU 설정"""
        self.gpu_config = auto_setup()
        self.device = self.gpu_config['device']
        
        # Transkun 경로 설정 (시스템 환경에 맞게 조정)
        # 기본적으로 pip 설치 경로를 탐색합니다.
        self.conf_path = self._find_transkun_resource("pretrained/2.0.conf")
        self.weight_path = self._find_transkun_resource("pretrained/2.0.pt")
        
    def _find_transkun_resource(self, relative_path):
        """transkun 패키지 내의 리소스 경로 탐색"""
        try:
            import transkun
            base_path = os.path.dirname(transkun.__file__)
            full_path = os.path.join(base_path, relative_path)
            if os.path.exists(full_path):
                return full_path
        except ImportError:
            pass
        
        # 폴백 경로 (사용자 제공 경로 기반)
        fallback_paths = [
            f"/usr/local/lib/python3.12/dist-packages/transkun/{relative_path}",
            f"/usr/local/lib/python3.11/dist-packages/transkun/{relative_path}",
            os.path.expanduser(f"~/.local/lib/python3.11/dist-packages/transkun/{relative_path}")
        ]
        for p in fallback_paths:
            if os.path.exists(p):
                return p
        return relative_path # 마지막 수단으로 상대 경로 반환

    def transcribe(self, input_path, output_path, progress_callback=None):
        """
        사용자 제공 로직을 활용한 MP3 to MIDI 변환
        """
        if not os.path.exists(input_path):
            if progress_callback:
                progress_callback(0, f"파일을 찾을 수 없음: {input_path}")
            return False

        try:
            if progress_callback:
                progress_callback(10, f"전사 준비 중... (Device: {self.device})")

            input_path = os.path.abspath(input_path)
            outfolder = os.path.dirname(os.path.abspath(output_path))
            os.makedirs(outfolder, exist_ok=True)
            
            # 사용자 제공 cmd 구조 반영
            cmd = [
                sys.executable,
                "-m", "transkun.transcribe",
                "--conf", self.conf_path,
                "--weight", self.weight_path,
                "--device", self.device,
                input_path,
                output_path
            ]

            if progress_callback:
                progress_callback(30, "Transkun V2 Semi-CRF 전사 시작...")

            # 서브프로세스 실행
            proc = subprocess.run(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE, 
                text=True
            )

            if proc.returncode != 0:
                error_msg = f"Transcription failed:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
                if progress_callback:
                    progress_callback(0, "전사 실패")
                print(error_msg)
                return False

            if progress_callback:
                progress_callback(100, "전사 완료!")
            
            return True

        except Exception as e:
            if progress_callback:
                progress_callback(0, f"오류: {str(e)}")
            print(f"Transcription error: {e}")
            return False

    def get_device_info(self):
        return self.gpu_config
