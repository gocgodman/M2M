#!/bin/bash

# 스크립트 오류 시 즉시 중단
set -e

echo "M2M Kivy App - Android 빌드를 시작합니다..."

# 1. Buildozer 설치 (이미 설치되지 않은 경우)
if ! command -v buildozer &> /dev/null
then
    echo "Buildozer를 설치합니다..."
    sudo pip3 install buildozer
else
    echo "Buildozer가 이미 설치되어 있습니다."
fi

# 2. 시스템 의존성 업데이트 (필요시)
echo "시스템 패키지 목록을 업데이트합니다..."
sudo apt-get update -y

# 3. Buildozer가 요구하는 의존성 설치
echo "Buildozer 의존성을 설치합니다..."
sudo apt-get install -y \
    git \
    zip \
    unzip \
    build-essential \
    python3-dev \
    libffi-dev \
    libssl-dev \
    libsqlite3-dev \
    zlib1g-dev \
    autoconf \
    autogen \
    libtool \
    pkg-config \
    cmake \
    ccache

# 4. Buildozer를 사용하여 Android 디버그 APK 빌드
# --verbose 옵션으로 상세 로그 출력
echo "Buildozer를 사용하여 Android 디버그 APK를 빌드합니다..."
buildozer android debug --verbose

# 5. 빌드 완료 메시지
echo "빌드가 완료되었습니다!"

# 생성된 APK 파일 경로 찾기
APK_PATH=$(find bin -name "*.apk" | head -n 1)

if [ -f "$APK_PATH" ]; then
    echo "생성된 APK 파일: $APK_PATH"
    echo "이 파일을 Android 기기에 설치하여 테스트할 수 있습니다."
else
    echo "오류: APK 파일을 찾을 수 없습니다. 빌드 로그를 확인하세요."
    exit 1
fi

exit 0
