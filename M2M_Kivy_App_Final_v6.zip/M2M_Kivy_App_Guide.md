# M2M (MP3 to MIDI) Kivy 모바일 앱 개발 가이드

**작성자**: Manus AI  
**작성일**: 2026년 1월 20일

---

## 프로젝트 개요

본 프로젝트는 Jupyter 노트북 형태로 작성된 MP3 to MIDI 변환 코드를 분석하여, **Kivy 프레임워크**를 활용한 크로스플랫폼 모바일 애플리케이션으로 재구성한 것입니다. 특히 **GPU 가속**을 적극적으로 활용하여 모바일 환경에서도 빠른 오디오 전사(transcription) 성능을 제공하는 것을 목표로 합니다.

원본 노트북은 Google Colab 환경에서 실행되도록 설계되었으며, `transkun` v2.0 라이브러리를 사용하여 PyTorch 기반의 딥러닝 모델을 통해 오디오 파일을 MIDI로 변환합니다. 이를 모바일 앱으로 전환하면서 다음과 같은 주요 개선 사항을 적용했습니다.

- **Kivy UI 통합**: 사용자가 직관적으로 파일을 선택하고 변환 과정을 모니터링할 수 있는 모바일 친화적 인터페이스를 구현했습니다.
- **GPU 자동 감지 및 최적화**: CUDA(NVIDIA), MPS(Apple Silicon), Vulkan/OpenGL ES(Android) 등 다양한 GPU 백엔드를 자동으로 감지하고 최적화 설정을 적용합니다.
- **모바일 빌드 자동화**: Buildozer를 사용하여 Android APK를 손쉽게 빌드할 수 있도록 설정 파일과 스크립트를 제공합니다.

---

## 프로젝트 구조 및 파일 설명

프로젝트는 다음과 같은 구조로 구성되어 있습니다.

| 파일명 | 설명 |
|--------|------|
| `main.py` | Kivy 앱의 메인 로직과 UI를 정의합니다. 파일 선택, 변환 시작, 로그 표시 등의 기능을 포함합니다. |
| `transcription_engine.py` | MP3 to MIDI 변환을 수행하는 핵심 엔진입니다. `transkun` 라이브러리를 호출하고 GPU 가속을 적용합니다. |
| `gpu_config.py` | 실행 환경의 GPU를 자동으로 감지하고 최적화 설정을 적용하는 모듈입니다. CUDA, MPS, Vulkan 등을 지원합니다. |
| `requirements.txt` | Python 의존성 목록입니다. Kivy, PyTorch, transkun 등이 포함됩니다. |
| `buildozer.spec` | Android 빌드를 위한 Buildozer 설정 파일입니다. 앱 이름, 패키지명, 권한, 아키텍처 등을 정의합니다. |
| `build.sh` | Android APK를 자동으로 빌드하는 Bash 스크립트입니다. Buildozer 설치 및 빌드 과정을 자동화합니다. |
| `README.md` | 프로젝트 설명 및 사용 방법을 담은 문서입니다. |

---

## 핵심 기술 스택

본 프로젝트는 다음과 같은 주요 라이브러리와 기술을 사용합니다.

### 1. Kivy (UI 프레임워크)

**Kivy**는 Python으로 작성된 오픈소스 크로스플랫폼 GUI 프레임워크로, Android, iOS, Windows, macOS, Linux 등 다양한 플랫폼에서 동작하는 애플리케이션을 개발할 수 있습니다. 터치 인터페이스를 기본적으로 지원하여 모바일 앱 개발에 적합합니다.

본 프로젝트에서는 Kivy의 `BoxLayout`, `Button`, `Label`, `FileChooser`, `ProgressBar` 등의 위젯을 사용하여 직관적인 UI를 구성했습니다. 또한 Android 권한 요청을 위해 `android.permissions` 모듈을 활용했습니다.

### 2. PyTorch (딥러닝 프레임워크)

**PyTorch**는 Facebook AI Research에서 개발한 오픈소스 딥러닝 프레임워크로, 동적 계산 그래프와 직관적인 API를 제공합니다. 특히 CUDA를 통한 NVIDIA GPU 가속, MPS를 통한 Apple Silicon 가속을 지원하여 모바일 환경에서도 높은 성능을 발휘할 수 있습니다.

본 프로젝트에서는 PyTorch를 통해 `transkun` 모델을 실행하며, `torch.inference_mode()`를 사용하여 추론 시 메모리 사용량을 최적화했습니다. 또한 `torch.backends.cudnn.benchmark`를 활성화하여 GPU 성능을 극대화했습니다.

### 3. Transkun (오디오 전사 라이브러리)

**Transkun**은 오디오 파일을 MIDI로 변환하는 Python 라이브러리로, PyTorch 기반의 딥러닝 모델을 사용합니다. v2.0부터는 더욱 정확한 전사 성능을 제공하며, GPU 가속을 통해 빠른 처리 속도를 자랑합니다.

본 프로젝트에서는 `transkun.transcribe()` 함수를 호출하여 MP3 파일을 MIDI로 변환하며, `device` 파라미터를 통해 사용할 디바이스(CPU/GPU)를 명시적으로 지정합니다.

### 4. Buildozer (Android 빌드 도구)

**Buildozer**는 Python 애플리케이션을 Android 및 iOS 패키지로 빌드하는 도구로, Kivy 앱을 모바일 플랫폼에 배포할 때 필수적으로 사용됩니다. `buildozer.spec` 파일을 통해 앱의 메타데이터, 권한, 의존성 등을 설정할 수 있습니다.

본 프로젝트에서는 `buildozer android debug` 명령을 통해 디버그 APK를 생성하며, `android.archs`를 `arm64-v8a`와 `armeabi-v7a`로 설정하여 대부분의 Android 기기를 지원합니다.

---

## GPU 가속 구현 상세

본 프로젝트의 핵심 차별점은 **GPU 가속을 적극적으로 활용**한다는 점입니다. `gpu_config.py` 모듈은 실행 환경을 자동으로 감지하고 최적의 설정을 적용합니다.

### GPU 감지 로직

`GPUConfig.setup_gpu()` 메서드는 다음 순서로 GPU를 감지합니다.

1. **CUDA (NVIDIA GPU)**: `torch.cuda.is_available()`로 CUDA 지원 여부를 확인합니다. 감지되면 `torch.backends.cudnn.enabled`와 `torch.backends.cudnn.benchmark`를 활성화하여 성능을 극대화합니다.

2. **MPS (Apple Silicon)**: `torch.backends.mps.is_available()`로 Apple Silicon GPU 지원 여부를 확인합니다. M1/M2/M3 칩에서는 MPS 백엔드를 사용하여 GPU 가속을 제공합니다.

3. **CPU Fallback**: 사용 가능한 GPU가 없으면 CPU를 사용하며, `torch.set_num_threads()`를 통해 멀티스레드 성능을 최적화합니다.

### 모바일 환경 최적화

모바일 환경에서는 메모리와 전력 소비가 중요한 고려 사항입니다. `GPUConfig.optimize_for_mobile()` 메서드는 다음과 같은 최적화를 적용합니다.

- **cuDNN Benchmark 비활성화**: 모바일 GPU는 일반적으로 메모리가 제한적이므로, 벤치마크 모드를 비활성화하여 메모리 사용량을 줄입니다.
- **CUDA 메모리 단편화 방지**: `PYTORCH_CUDA_ALLOC_CONF` 환경 변수를 설정하여 메모리 할당 크기를 제한합니다.
- **Float32 정밀도 조정**: `torch.set_float32_matmul_precision('medium')`을 통해 정밀도를 약간 낮춰 성능을 향상시킵니다.

### Android GPU 지원

Android 환경에서는 PyTorch Mobile이 Vulkan 백엔드를 지원합니다. `setup_android_gpu()` 함수는 Vulkan 사용 가능 여부를 확인하고, 사용할 수 없으면 OpenGL ES로 폴백합니다. 또한 Kivy의 그래픽 백엔드를 `sdl2`로 설정하여 모바일 GPU를 효과적으로 활용합니다.

---

## 빌드 및 배포 가이드

### 데스크톱 환경에서 테스트

모바일 빌드 전에 데스크톱 환경에서 앱을 테스트하는 것이 권장됩니다.

1. **가상 환경 생성 및 활성화**

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

2. **의존성 설치**

   ```bash
   pip install -r requirements.txt
   ```

   PyTorch는 시스템에 맞게 별도로 설치해야 할 수 있습니다. [PyTorch 공식 웹사이트](https://pytorch.org/get-started/locally/)에서 설치 명령을 확인하세요.

3. **앱 실행**

   ```bash
   python main.py
   ```

   Kivy 창이 열리면 "MP3 파일 선택" 버튼을 눌러 오디오 파일을 선택하고 "MIDI 변환" 버튼을 눌러 변환을 시작할 수 있습니다.

### Android APK 빌드

Android APK를 빌드하려면 Linux 환경(Ubuntu 권장)이 필요합니다.

1. **빌드 스크립트 실행 권한 부여**

   ```bash
   chmod +x build.sh
   ```

2. **빌드 스크립트 실행**

   ```bash
   ./build.sh
   ```

   이 스크립트는 Buildozer를 설치하고 필요한 시스템 의존성을 설치한 후, `buildozer android debug` 명령을 실행하여 디버그 APK를 생성합니다.

3. **APK 설치 및 테스트**

   빌드가 완료되면 `bin/` 디렉터리에 `m2m-1.0.0-arm64-v8a-debug.apk` 파일이 생성됩니다. 이 파일을 Android 기기로 전송하고 설치하여 테스트할 수 있습니다.

   ```bash
   adb install bin/m2m-1.0.0-arm64-v8a-debug.apk
   ```

### iOS 빌드 (참고)

iOS 빌드는 macOS 환경과 Xcode가 필요하며, Buildozer 대신 `kivy-ios` 도구를 사용합니다. 본 프로젝트는 Android를 주요 타겟으로 하지만, iOS 빌드도 가능합니다. 자세한 내용은 [Kivy 공식 문서](https://kivy.org/doc/stable/guide/packaging-ios.html)를 참조하세요.

---

## 주요 기능 및 사용 방법

### 1. 파일 선택

앱을 실행하면 메인 화면에 "MP3 파일 선택" 버튼이 표시됩니다. 이 버튼을 누르면 파일 선택 다이얼로그가 열리며, MP3, WAV, M4A 형식의 오디오 파일을 선택할 수 있습니다.

Android 환경에서는 `/storage/emulated/0/` 경로(내부 저장소)를 기본으로 표시하며, 데스크톱 환경에서는 사용자 홈 디렉터리를 표시합니다.

### 2. MIDI 변환

파일을 선택한 후 "MIDI 변환" 버튼을 누르면 변환이 시작됩니다. 변환 과정은 다음 단계로 진행됩니다.

1. **오디오 로드**: 선택한 파일을 메모리에 로드합니다.
2. **AI 모델 전사**: `transkun` 모델을 사용하여 오디오를 분석하고 MIDI 데이터를 생성합니다. 이 단계에서 GPU 가속이 적용됩니다.
3. **MIDI 파일 생성**: 변환된 MIDI 데이터를 파일로 저장합니다.

각 단계의 진행률은 화면 상단의 프로그레스 바에 표시되며, 하단의 로그 영역에서 상세한 메시지를 확인할 수 있습니다.

### 3. 결과 확인

변환이 완료되면 팝업 창이 표시되며, 생성된 MIDI 파일의 경로를 알려줍니다. Android 환경에서는 앱 전용 디렉터리(`/data/data/org.m2m.m2m/files/`)에 저장되며, 데스크톱 환경에서는 원본 파일과 같은 디렉터리에 저장됩니다.

---

## 성능 최적화 팁

### GPU 메모리 관리

모바일 환경에서는 GPU 메모리가 제한적이므로, 변환 작업 전후로 `torch.cuda.empty_cache()`를 호출하여 메모리를 정리하는 것이 중요합니다. 본 프로젝트에서는 `transcription_engine.py`의 `transcribe()` 메서드에서 이를 자동으로 처리합니다.

### 배치 사이즈 조정

`GPUConfig.get_optimal_batch_size()` 메서드는 GPU 메모리 크기에 따라 최적의 배치 사이즈를 반환합니다. 모바일 환경에서는 일반적으로 작은 배치 사이즈(2~4)를 사용하는 것이 안정적입니다.

### 혼합 정밀도 추론

NVIDIA GPU에서는 Automatic Mixed Precision(AMP)을 사용하여 Float16과 Float32를 혼합하여 추론 속도를 높일 수 있습니다. `GPUConfig.enable_mixed_precision()` 메서드가 이를 자동으로 감지하고 활성화합니다.

---

## 문제 해결

### 1. Buildozer 빌드 실패

Buildozer 빌드 중 오류가 발생하면 다음을 확인하세요.

- **Java 버전**: Buildozer는 Java 8 또는 11을 요구합니다. `java -version`으로 확인하세요.
- **Android SDK/NDK**: Buildozer가 자동으로 다운로드하지만, 네트워크 문제로 실패할 수 있습니다. 수동으로 다운로드하여 `buildozer.spec`에 경로를 지정할 수 있습니다.
- **의존성 충돌**: `requirements.txt`의 라이브러리 버전이 충돌할 수 있습니다. 특히 PyTorch는 모바일 환경에서 별도의 빌드 레시피가 필요할 수 있습니다.

### 2. transkun 설치 실패

`transkun`은 PyPI에 등록되어 있지만, 일부 의존성(예: `ncls`, `pretty-midi`)이 C 확장을 포함하므로 빌드 도구가 필요합니다. Ubuntu에서는 다음 패키지를 설치하세요.

```bash
sudo apt-get install build-essential python3-dev
```

### 3. GPU 인식 안 됨

GPU가 감지되지 않으면 다음을 확인하세요.

- **CUDA 드라이버**: NVIDIA GPU를 사용하는 경우 CUDA Toolkit과 드라이버가 설치되어 있어야 합니다.
- **PyTorch 버전**: PyTorch가 CUDA 지원 버전으로 설치되었는지 확인하세요. `torch.cuda.is_available()`로 테스트할 수 있습니다.
- **Android 환경**: Android에서는 PyTorch Mobile이 Vulkan을 지원해야 합니다. 빌드 레시피에 따라 지원 여부가 달라질 수 있습니다.

---

## 향후 개선 방향

본 프로젝트는 기본적인 MP3 to MIDI 변환 기능을 제공하지만, 다음과 같은 추가 기능을 구현할 수 있습니다.

- **페달 검출 및 CC 삽입**: 원본 노트북에 포함된 페달 검출 기능을 앱에 통합하여 더욱 정교한 MIDI 파일을 생성할 수 있습니다.
- **SF2 렌더링**: FluidSynth를 사용하여 MIDI 파일을 WAV로 렌더링하는 기능을 추가할 수 있습니다.
- **YouTube 다운로드**: `yt-dlp`를 통합하여 YouTube 동영상의 오디오를 직접 다운로드하고 변환할 수 있습니다.
- **배치 처리**: 여러 파일을 한 번에 변환하는 배치 처리 기능을 추가할 수 있습니다.
- **클라우드 백엔드**: 모바일 기기의 성능이 제한적인 경우, 클라우드 서버에서 변환을 수행하고 결과를 다운로드하는 방식으로 전환할 수 있습니다.

---

## 결론

본 프로젝트는 Jupyter 노트북 형태의 MP3 to MIDI 변환 코드를 Kivy 기반의 크로스플랫폼 모바일 앱으로 성공적으로 전환한 사례입니다. GPU 가속을 적극적으로 활용하여 모바일 환경에서도 빠른 처리 속도를 제공하며, Buildozer를 통해 Android APK를 손쉽게 빌드할 수 있도록 구성했습니다.

제공된 코드와 문서를 바탕으로 앱을 빌드하고 배포할 수 있으며, 필요에 따라 추가 기능을 구현하여 더욱 강력한 오디오 전사 도구로 발전시킬 수 있습니다.

---

**참고 자료**

- [Kivy 공식 문서](https://kivy.org/doc/stable/)
- [PyTorch 공식 문서](https://pytorch.org/docs/stable/index.html)
- [Buildozer 공식 문서](https://buildozer.readthedocs.io/)
- [Transkun GitHub](https://github.com/gocgodman/M2M)
